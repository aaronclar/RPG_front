import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonContent, IonTitle, IonButton, IonCol, IonRow } from '@ionic/angular/standalone';
import {FormsModule} from '@angular/forms'
import { AuthService } from '@auth0/auth0-angular';

@Component({
  selector: 'app-logros',
  templateUrl: './logros.page.html',
  styleUrls: ['./logros.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, IonContent, IonTitle,IonButton, IonCol, IonRow ]
})
export class LogrosPage implements OnInit {

  public pez0Count: number = 0
  public pez1Count: number = 0
  public pez2Count: number = 0
  public pez3Count: number = 0
  public pez4Count: number = 0
  public pez5Count: number = 0
  public pez6Count: number = 0
  public pez7Count: number = 0
  public pez8Count: number = 0
  public pez9Count: number = 0
  public pez10Count: number = 0
  public pez11Count: number = 0
  public pez12Count: number = 0
  public pez13Count: number = 0
  public pez14Count: number = 0
  public pez0Level: number = 10
  public pez1Level: number = 10
  public pez2Level: number = 10
  public pez3Level: number = 10
  public pez4Level: number = 10
  public pez5Level: number = 10
  public pez6Level: number = 10
  public pez7Level: number = 10
  public pez8Level: number = 10
  public pez9Level: number = 10
  public pez10Level: number = 10
  public pez11Level: number = 10
  public pez12Level: number = 10
  public pez13Level: number = 10
  public pez14Level: number = 10
  public desactivadoPez0: boolean = true
  public desactivadoPez1: boolean = true
  public desactivadoPez2: boolean = true
  public desactivadoPez3: boolean = true
  public desactivadoPez4: boolean = true
  public desactivadoPez5: boolean = true
  public desactivadoPez6: boolean = true
  public desactivadoPez7: boolean = true
  public desactivadoPez8: boolean = true
  public desactivadoPez9: boolean = true
  public desactivadoPez10: boolean = true
  public desactivadoPez11: boolean = true
  public desactivadoPez12: boolean = true
  public desactivadoPez13: boolean = true
  public desactivadoPez14: boolean = true
  public coins: number = 0
  public catch: number = 0
  public pesca: number = 100
  public user: any
  public usuario: any
  constructor(private auth: AuthService) { }

  ngOnInit() {
    this.pesca = localStorage.getItem('pesca') != null ? Number(localStorage.getItem('pesca')) : this.pesca;
    this.coins = localStorage.getItem('coins') != null ? Number(localStorage.getItem('coins')) : this.coins;
    this.pez0Count = localStorage.getItem('pez0Count') != null ? Number(localStorage.getItem('pez0Count')) : this.pez0Count;
    this.pez1Count = localStorage.getItem('pez1Count') != null ? Number(localStorage.getItem('pez1Count')) : this.pez1Count;
    this.pez2Count = localStorage.getItem('pez2Count') != null ? Number(localStorage.getItem('pez2Count')) : this.pez2Count;
    this.pez3Count = localStorage.getItem('pez3Count') != null ? Number(localStorage.getItem('pez3Count')) : this.pez3Count;
    this.pez4Count = localStorage.getItem('pez4Count') != null ? Number(localStorage.getItem('pez4Count')) : this.pez4Count;
    this.pez5Count = localStorage.getItem('pez5Count') != null ? Number(localStorage.getItem('pez5Count')) : this.pez5Count;
    this.pez6Count = localStorage.getItem('pez6Count') != null ? Number(localStorage.getItem('pez6Count')) : this.pez6Count;
    this.pez7Count = localStorage.getItem('pez7Count') != null ? Number(localStorage.getItem('pez7Count')) : this.pez7Count;
    this.pez8Count = localStorage.getItem('pez8Count') != null ? Number(localStorage.getItem('pez8Count')) : this.pez8Count;
    this.pez9Count = localStorage.getItem('pez9Count') != null ? Number(localStorage.getItem('pez9Count')) : this.pez9Count;
    this.pez10Count = localStorage.getItem('pez10Count') != null ? Number(localStorage.getItem('pez10Count')) : this.pez10Count;
    this.pez11Count = localStorage.getItem('pez11Count') != null ? Number(localStorage.getItem('pez11Count')) : this.pez11Count;
    this.pez12Count = localStorage.getItem('pez12Count') != null ? Number(localStorage.getItem('pez12Count')) : this.pez12Count;
    this.pez13Count = localStorage.getItem('pez13Count') != null ? Number(localStorage.getItem('pez13Count')) : this.pez13Count;
    this.pez14Count = localStorage.getItem('pez14Count') != null ? Number(localStorage.getItem('pez14Count')) : this.pez14Count;
    this.pez0Level = localStorage.getItem('pez0Level') != null ? Number(localStorage.getItem('pez0Level')) : this.pez0Level;
    this.pez1Level = localStorage.getItem('pez1Level') != null ? Number(localStorage.getItem('pez1Level')) : this.pez1Level;
    this.pez2Level = localStorage.getItem('pez2Level') != null ? Number(localStorage.getItem('pez2Level')) : this.pez2Level;
    this.pez3Level = localStorage.getItem('pez3Level') != null ? Number(localStorage.getItem('pez3Level')) : this.pez3Level;
    this.pez4Level = localStorage.getItem('pez4Level') != null ? Number(localStorage.getItem('pez4Level')) : this.pez4Level;
    this.pez5Level = localStorage.getItem('pez5Level') != null ? Number(localStorage.getItem('pez5Level')) : this.pez5Level;
    this.pez6Level = localStorage.getItem('pez6Level') != null ? Number(localStorage.getItem('pez6Level')) : this.pez6Level;
    this.pez7Level = localStorage.getItem('pez7Level') != null ? Number(localStorage.getItem('pez7Level')) : this.pez7Level;
    this.pez8Level = localStorage.getItem('pez8Level') != null ? Number(localStorage.getItem('pez8Level')) : this.pez8Level;
    this.pez9Level = localStorage.getItem('pez9Level') != null ? Number(localStorage.getItem('pez9Level')) : this.pez9Level;
    this.pez10Level = localStorage.getItem('pez10Level') != null ? Number(localStorage.getItem('pez10Level')) : this.pez10Level;
    this.pez11Level = localStorage.getItem('pez11Level') != null ? Number(localStorage.getItem('pez11Level')) : this.pez11Level;
    this.pez12Level = localStorage.getItem('pez12Level') != null ? Number(localStorage.getItem('pez12Level')) : this.pez12Level;
    this.pez13Level = localStorage.getItem('pez13Level') != null ? Number(localStorage.getItem('pez13Level')) : this.pez13Level;
    this.pez14Level = localStorage.getItem('pez14Level') != null ? Number(localStorage.getItem('pez14Level')) : this.pez14Level;
    this.catch = this.pez0Count + this.pez1Count + this.pez2Count + this.pez3Count + this.pez4Count + this.pez5Count + this.pez6Count + this.pez7Count + this.pez8Count + this.pez9Count + this.pez10Count + this.pez11Count + this.pez12Count + this.pez13Count + this.pez14Count
    setInterval(() => {
      this.checkdisable();
  }, 1000);
  localStorage.setItem('pesca', String(this.pesca));
  this.auth.user$.subscribe((data) =>{
    this.user =data
    console.log(this.user);
    this.usuario = {
      email: this.user.email,
      name: this.user.name,
      picture: this.user.picture
    }
    localStorage.setItem(JSON.stringify(this.usuario.email) , JSON.stringify(this.usuario))
  })
  }
  funPez0(){
    this.coins = this.coins + (this.pez0Level * 5)
    this.pez0Level *= 10
    this.desactivadoPez0 = true
    localStorage.setItem('pez0Count', String(this.pez0Count));
    localStorage.setItem('pez0Level', String(this.pez0Level));
    localStorage.setItem('coins', String(this.coins));
  }
  funPez1(){
    this.coins = this.coins + (this.pez1Level * 10)
    this.pez1Level *= 10
    this.desactivadoPez1 = true
    localStorage.setItem('pez1Count', String(this.pez1Count));
    localStorage.setItem('pez1Level', String(this.pez1Level));
    localStorage.setItem('coins', String(this.coins));
  }
  funPez2(){
    this.coins = this.coins + (this.pez2Level * 25)
    this.pez2Level *= 10
    this.desactivadoPez2 = true
    localStorage.setItem('pez2Count', String(this.pez2Count));
    localStorage.setItem('pez2Level', String(this.pez2Level));
    localStorage.setItem('coins', String(this.coins));
  }
  funPez3(){
    this.coins = this.coins + (this.pez3Level * 50)
    this.pez3Level *= 10
    this.desactivadoPez3 = true
    localStorage.setItem('pez3Count', String(this.pez0Count));
    localStorage.setItem('pez3Level', String(this.pez0Level));
    localStorage.setItem('coins', String(this.coins));
  }
  funPez4(){
    this.coins = this.coins + (this.pez4Level * 75)
    this.pez4Level *= 10
    this.desactivadoPez4 = true
    localStorage.setItem('pez4Count', String(this.pez4Count));
    localStorage.setItem('pez4Level', String(this.pez4Level));
    localStorage.setItem('coins', String(this.coins));
  }
  funPez5(){
    this.coins =  this.coins + (this.pez5Level * 100)
    this.pez5Level *= 10
    this.desactivadoPez5 = true
    localStorage.setItem('pez5Count', String(this.pez5Count));
    localStorage.setItem('pez5Level', String(this.pez5Level));
    localStorage.setItem('coins', String(this.coins));
  }
  funPez6(){
    this.coins =  this.coins + (this.pez6Level * 125)
    this.pez6Level *= 10
    this.desactivadoPez6 = true
    localStorage.setItem('pez6Count', String(this.pez6Count));
    localStorage.setItem('pez6Level', String(this.pez6Level));
    localStorage.setItem('coins', String(this.coins));
  }
  funPez7(){
    this.coins =  this.coins + (this.pez7Level * 150)
    this.pez7Level *= 10
    this.desactivadoPez7 = true
    localStorage.setItem('pez7Count', String(this.pez7Count));
    localStorage.setItem('pez7Level', String(this.pez7Level));
    localStorage.setItem('coins', String(this.coins));
  }
  funPez8(){
    this.coins =  this.coins + (this.pez8Level * 200)
    this.pez8Level *= 10
    this.desactivadoPez8 = true
    localStorage.setItem('pez8Count', String(this.pez0Count));
    localStorage.setItem('pez8Level', String(this.pez0Level));
    localStorage.setItem('coins', String(this.coins));
  }
  funPez9(){
    this.coins =  this.coins + (this.pez9Level * 225)
    this.pez9Level *= 10
    this.desactivadoPez9 = true
    localStorage.setItem('pez9Count', String(this.pez9Count));
    localStorage.setItem('pez9Level', String(this.pez9Level));
    localStorage.setItem('coins', String(this.coins));
  }
  funPez10(){
    this.coins = this.coins + (this.pez10Level * 250)
    this.pez10Level *= 10
    this.desactivadoPez10 = true
    localStorage.setItem('pez10Count', String(this.pez10Count));
    localStorage.setItem('pez10Level', String(this.pez10Level));
    localStorage.setItem('coins', String(this.coins));
  }
  funPez11(){
    this.coins =  this.coins + (this.pez11Level * 275)
    this.pez11Level *= 10
    this.desactivadoPez11 = true
    localStorage.setItem('pez11Count', String(this.pez11Count));
    localStorage.setItem('pez11Level', String(this.pez11Level));
    localStorage.setItem('coins', String(this.coins));
  }
  funPez12(){
    this.coins =  this.coins + (this.pez12Level * 300)
    this.pez12Level *= 10
    this.desactivadoPez12 = true
    localStorage.setItem('pez12Count', String(this.pez12Count));
    localStorage.setItem('pez0Level', String(this.pez12Level));
    localStorage.setItem('coins', String(this.coins));
  }
  funPez13(){
    this.coins =  this.coins + (this.pez13Level * 325)
    this.pez13Level *= 10
    this.desactivadoPez13 = true
    localStorage.setItem('pez13Count', String(this.pez13Count));
    localStorage.setItem('pez13Level', String(this.pez13Level));
    localStorage.setItem('coins', String(this.coins));
  }
  funPez14(){
    this.coins =  this.coins + (this.pez14Level * 500)
    this.pez14Level *= 10
    this.desactivadoPez14 = true
    localStorage.setItem('pez14Count', String(this.pez14Count));
    localStorage.setItem('pez14Level', String(this.pez14Level));
    localStorage.setItem('coins', String(this.coins));
  }

  checkdisable(){
    if(this.pez0Count >= this.pez0Level){
      this.desactivadoPez0 = false
    } else{
      this.desactivadoPez0 = true
    }
    if(this.pez1Count >= this.pez1Level){
      this.desactivadoPez1 = false
    } else{
      this.desactivadoPez1 = true
    }
    if(this.pez2Count >= this.pez2Level){
      this.desactivadoPez2 = false
    } else{
      this.desactivadoPez2 = true
    }
    if(this.pez3Count >= this.pez3Level){
      this.desactivadoPez3 = false
    } else{
      this.desactivadoPez3 = true
    }
    if(this.pez4Count >= this.pez4Level){
      this.desactivadoPez4 = false
    } else{
      this.desactivadoPez4 = true
    }
    if(this.pez5Count >= this.pez5Level){
      this.desactivadoPez5 = false
    } else{
      this.desactivadoPez5 = true
    }
    if(this.pez6Count >= this.pez6Level){
      this.desactivadoPez6 = false
    } else{
      this.desactivadoPez6 = true
    }
    if(this.pez7Count >= this.pez7Level){
      this.desactivadoPez7 = false
    } else{
      this.desactivadoPez7 = true
    }
    if(this.pez8Count >= this.pez8Level){
      this.desactivadoPez8 = false
    } else{
      this.desactivadoPez8 = true
    }
    if(this.pez9Count >= this.pez9Level){
      this.desactivadoPez9 = false
    } else{
      this.desactivadoPez9 = true
    }
    if(this.pez10Count >= this.pez10Level){
      this.desactivadoPez10 = false
    } else{
      this.desactivadoPez10 = true
    }
    if(this.pez11Count >= this.pez11Level){
      this.desactivadoPez11 = false
    } else{
      this.desactivadoPez11 = true
    }
    if(this.pez12Count >= this.pez12Level){
      this.desactivadoPez12 = false
    } else{
      this.desactivadoPez12 = true
    }
    if(this.pez13Count >= this.pez13Level){
      this.desactivadoPez13 = false
    } else{
      this.desactivadoPez13 = true
    }
    if(this.pez14Count >= this.pez14Level){
      this.desactivadoPez14 = false
    } else{
      this.desactivadoPez14 = true
    }
  }  
}
