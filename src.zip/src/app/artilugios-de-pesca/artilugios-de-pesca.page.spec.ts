import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ArtilugiosDePescaPage } from './artilugios-de-pesca.page';

describe('ArtilugiosDePescaPage', () => {
  let component: ArtilugiosDePescaPage;
  let fixture: ComponentFixture<ArtilugiosDePescaPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(ArtilugiosDePescaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
