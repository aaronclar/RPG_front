import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonContent, IonTitle, IonButton, IonCol, IonGrid, IonRow, IonImg } from '@ionic/angular/standalone';
import {FormsModule} from '@angular/forms'
import { AuthService } from '@auth0/auth0-angular';


@Component({
  selector: 'app-artilugios-de-pesca',
  templateUrl: './artilugios-de-pesca.page.html',
  styleUrls: ['./artilugios-de-pesca.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule,IonContent, IonTitle,IonButton, IonCol, IonGrid, IonRow, IonImg ]
})
export class ArtilugiosDePescaPage implements OnInit {

  public salabreParts: number = 0
  public salabreLevel: number = 1
  public canaParts: number = 0
  public canaLevel: number = 1
  public carreteLevel: number = 1
  public carreteParts: number = 0
  public carreteEffect: number = 0
  public canaEffect: number = 0
  public desactivadoCana: boolean = true
  public desactivadoCarrete: boolean = true
  public desactivadoSalabre: boolean = true
  public pesca: number = 100
  public user: any;
  public usuario: any;

  constructor(private auth: AuthService) { }

  ngOnInit() {
    this.canaParts = localStorage.getItem('canaParts') != null ? Number(localStorage.getItem('canaParts')) : this.canaParts;
    this.canaLevel = localStorage.getItem('canaLevel') != null ? Number(localStorage.getItem('canaLevel')) : this.canaLevel;
    this.carreteParts = localStorage.getItem('carreteParts') != null ? Number(localStorage.getItem('carreteParts')) : this.carreteParts;
    this.carreteLevel = localStorage.getItem('carreteLevel') != null ? Number(localStorage.getItem('carreteLevel')) : this.carreteLevel;
    this.salabreParts = localStorage.getItem('salabreParts') != null ? Number(localStorage.getItem('salabreParts')) : this.salabreParts;
    this.salabreLevel = localStorage.getItem('salabreLevel') != null ? Number(localStorage.getItem('salabreLevel')) : this.salabreLevel;
    this.canaEffect = localStorage.getItem('canaEffect') != null ? Number(localStorage.getItem('canaEffect')) : this.canaEffect;
    this.carreteEffect = localStorage.getItem('carreteEffect') != null ? Number(localStorage.getItem('carreteEffect')) : this.carreteEffect;
    this.pesca = localStorage.getItem('pesca') != null ? Number(localStorage.getItem('pesca')) : this.pesca;
    setInterval(() => {
      this.checkDisable();
  }, 1000);
  this.auth.user$.subscribe((data) =>{
    this.user =data
    console.log(this.user);
    this.usuario = {
      email: this.user.email,
      name: this.user.name,
      picture: this.user.picture
    }
    localStorage.setItem(this.usuario.email, JSON.stringify(this.usuario))
  })

  }

  cana(){
    this.canaLevel += 1
    this.canaParts -= 10
    this.canaEffect += 1
    localStorage.setItem('canaParts', String(this.canaParts));
    localStorage.setItem('canaLevel', String(this.canaLevel));
    localStorage.setItem('canaEffect', String(this.canaEffect));
  }
  carrete(){
    this.carreteLevel += 1
    this.carreteParts -= 10
    this.carreteEffect += 1
    localStorage.setItem('carreteParts', String(this.carreteParts));
    localStorage.setItem('carreteLevel', String(this.carreteLevel));
    localStorage.setItem('carreteEffect', String(this.carreteEffect));
  }
  salabre(){
    this.salabreLevel += 1
    this.salabreParts -= 10
    this.pesca += 20
    localStorage.setItem('salabreParts', String(this.salabreParts));
    localStorage.setItem('salabreLevel', String(this.salabreLevel));
    localStorage.setItem('pesca', String(this.pesca));
  }

  checkDisable(){
    if(this.canaParts >= 10){
      this.desactivadoCana = false
    } else{
      this.desactivadoCana = true
    }
    if(this.carreteParts >= 10){
      this.desactivadoCarrete = false
    } else{
      this.desactivadoCarrete = true
    }
    if(this.salabreParts >= 10){
      this.desactivadoSalabre = false
    } else{
      this.desactivadoSalabre = true
    }
  }
}
