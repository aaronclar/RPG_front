import { Component, OnInit, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonButton } from '@ionic/angular/standalone';
import { AuthService } from '@auth0/auth0-angular';
import { DOCUMENT } from '@angular/common';



@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: true,
  imports: [IonContent, IonHeader, IonTitle, IonToolbar, CommonModule, FormsModule, IonButton]
})
export class LoginPage implements OnInit {
  public pez0Count: number = 0
  public pez1Count: number = 0
  public pez2Count: number = 0
  public pez3Count: number = 0
  public pez4Count: number = 0
  public pez5Count: number = 0
  public pez6Count: number = 0
  public pez7Count: number = 0
  public pez8Count: number = 0
  public pez9Count: number = 0
  public pez10Count: number = 0
  public pez11Count: number = 0
  public pez12Count: number = 0
  public pez13Count: number = 0
  public pez14Count: number = 0
  public pez0Level: number = 10
  public pez1Level: number = 10
  public pez2Level: number = 10
  public pez3Level: number = 10
  public pez4Level: number = 10
  public pez5Level: number = 10
  public pez6Level: number = 10
  public pez7Level: number = 10
  public pez8Level: number = 10
  public pez9Level: number = 10
  public pez10Level: number = 10
  public pez11Level: number = 10
  public pez12Level: number = 10
  public pez13Level: number = 10
  public pez14Level: number = 10
  public desactivadoPez0: boolean = true
  public desactivadoPez1: boolean = true
  public desactivadoPez2: boolean = true
  public desactivadoPez3: boolean = true
  public desactivadoPez4: boolean = true
  public desactivadoPez5: boolean = true
  public desactivadoPez6: boolean = true
  public desactivadoPez7: boolean = true
  public desactivadoPez8: boolean = true
  public desactivadoPez9: boolean = true
  public desactivadoPez10: boolean = true
  public desactivadoPez11: boolean = true
  public desactivadoPez12: boolean = true
  public desactivadoPez13: boolean = true
  public desactivadoPez14: boolean = true
  public salabreParts: number = 0
  public salabreLevel: number = 1
  public canaParts: number = 0
  public canaLevel: number = 1
  public carreteLevel: number = 1
  public carreteParts: number = 0
  public carreteEffect: number = 0
  public canaEffect: number = 0
  public desactivadoCana: boolean = true
  public desactivadoCarrete: boolean = true
  public desactivadoSalabre: boolean = true
  public coins: number = 0
  public catch: number = 0
  public pesca: number = 100
  public multClicks: number = 1
  public multLevel: number = 1
  public multPrice: number = 2
  public pescaLevel: number = 1
  public autoLevel: number = 1
  public fishAuto: number = 0
  public autoPrice: number = 5
  public pescaPrice: number = 2
  public coinsAdd: number = 0
  public coinsPrice: number = 3
  public coinsLevel: number = 1
  public fishPriceMult: number = 1
  public fishPriceMultLevel: number = 1
  public desactivadoMultClicks: boolean = true
  public desactivadoPesca: boolean = true
  public desactivadoAutoFish: boolean = true
  public desactivadoCoinsAdded: boolean = true
  public desactivadoMultFishPrice: boolean = true
  public prestigioLevel: number = 0
  public prestigioClicks: number = 0
  public prestigioFishPrice: number = 1
  public prestigioAuto: number = 0
  public prestigioCoins: number = 0
  public user: any;
  public usuario: any
  public state: any;
  constructor(private auth: AuthService, @Inject(DOCUMENT) public document: Document) { }

  ngOnInit() {
    this.prestigioLevel = localStorage.getItem('prestigioLevel') != null ? Number(localStorage.getItem('prestigioLevel')) : this.prestigioLevel;
    this.prestigioClicks = localStorage.getItem('prestigioClicks') != null ? Number(localStorage.getItem('prestigioClicks')) : this.prestigioClicks;
    this.prestigioFishPrice = localStorage.getItem('prestigioFishPrice') != null ? Number(localStorage.getItem('prestigioFishPrice')) : this.prestigioFishPrice;
    this.prestigioAuto = localStorage.getItem('prestigioAuto') != null ? Number(localStorage.getItem('prestigioAuto')) : this.prestigioAuto;
    this.prestigioCoins = localStorage.getItem('prestigioCoins') != null ? Number(localStorage.getItem('prestigioCoins')) : this.prestigioCoins;
    this.multLevel = localStorage.getItem('multLevel') != null ? Number(localStorage.getItem('multLevel')) : this.multLevel;
    this.multClicks = localStorage.getItem('multClicks') != null ? Number(localStorage.getItem('multClicks')) : this.multClicks;
    this.pescaLevel = localStorage.getItem('pescaLevel') != null ? Number(localStorage.getItem('pescaLevel')) : this.pescaLevel;
    this.autoLevel = localStorage.getItem('autoLevel') != null ? Number(localStorage.getItem('autoLevel')) : this.autoLevel;
    this.fishAuto = localStorage.getItem('fishAuto') != null ? Number(localStorage.getItem('fishAuto')) : this.fishAuto;
    this.autoPrice = localStorage.getItem('autoPrice') != null ? Number(localStorage.getItem('autoPrice')) : this.autoPrice;
    this.multPrice = localStorage.getItem('multPrice') != null ? Number(localStorage.getItem('multPrice')) : this.multPrice;
    this.pescaPrice = localStorage.getItem('pescaPrice') != null ? Number(localStorage.getItem('pescaPrice')) : this.pescaPrice;
    this.coinsAdd = localStorage.getItem('coinsAdd') != null ? Number(localStorage.getItem('coinsAdd')) : this.coinsAdd;
    this.coinsPrice = localStorage.getItem('coinsPrice') != null ? Number(localStorage.getItem('coinsPrice')) : this.coinsPrice;
    this.coinsLevel = localStorage.getItem('coinsLevel') != null ? Number(localStorage.getItem('coinsLevel')) : this.coinsLevel;
    this.fishPriceMult = localStorage.getItem('fishPriceMult') != null ? Number(localStorage.getItem('fishPriceMult')) : this.fishPriceMult;
    this.fishPriceMultLevel = localStorage.getItem('fishPriceMultLevel') != null ? Number(localStorage.getItem('fishPriceMultLevel')) : this.fishPriceMultLevel;
    this.canaParts = localStorage.getItem('canaParts') != null ? Number(localStorage.getItem('canaParts')) : this.canaParts;
    this.canaLevel = localStorage.getItem('canaLevel') != null ? Number(localStorage.getItem('canaLevel')) : this.canaLevel;
    this.carreteParts = localStorage.getItem('carreteParts') != null ? Number(localStorage.getItem('carreteParts')) : this.carreteParts;
    this.carreteLevel = localStorage.getItem('carreteLevel') != null ? Number(localStorage.getItem('carreteLevel')) : this.carreteLevel;
    this.salabreParts = localStorage.getItem('salabreParts') != null ? Number(localStorage.getItem('salabreParts')) : this.salabreParts;
    this.salabreLevel = localStorage.getItem('salabreLevel') != null ? Number(localStorage.getItem('salabreLevel')) : this.salabreLevel;
    this.canaEffect = localStorage.getItem('canaEffect') != null ? Number(localStorage.getItem('canaEffect')) : this.canaEffect;
    this.carreteEffect = localStorage.getItem('carreteEffect') != null ? Number(localStorage.getItem('carreteEffect')) : this.carreteEffect;
    this.pesca = localStorage.getItem('pesca') != null ? Number(localStorage.getItem('pesca')) : this.pesca;
    this.coins = localStorage.getItem('coins') != null ? Number(localStorage.getItem('coins')) : this.coins;
    this.pez0Count = localStorage.getItem('pez0Count') != null ? Number(localStorage.getItem('pez0Count')) : this.pez0Count;
    this.pez1Count = localStorage.getItem('pez1Count') != null ? Number(localStorage.getItem('pez1Count')) : this.pez1Count;
    this.pez2Count = localStorage.getItem('pez2Count') != null ? Number(localStorage.getItem('pez2Count')) : this.pez2Count;
    this.pez3Count = localStorage.getItem('pez3Count') != null ? Number(localStorage.getItem('pez3Count')) : this.pez3Count;
    this.pez4Count = localStorage.getItem('pez4Count') != null ? Number(localStorage.getItem('pez4Count')) : this.pez4Count;
    this.pez5Count = localStorage.getItem('pez5Count') != null ? Number(localStorage.getItem('pez5Count')) : this.pez5Count;
    this.pez6Count = localStorage.getItem('pez6Count') != null ? Number(localStorage.getItem('pez6Count')) : this.pez6Count;
    this.pez7Count = localStorage.getItem('pez7Count') != null ? Number(localStorage.getItem('pez7Count')) : this.pez7Count;
    this.pez8Count = localStorage.getItem('pez8Count') != null ? Number(localStorage.getItem('pez8Count')) : this.pez8Count;
    this.pez9Count = localStorage.getItem('pez9Count') != null ? Number(localStorage.getItem('pez9Count')) : this.pez9Count;
    this.pez10Count = localStorage.getItem('pez10Count') != null ? Number(localStorage.getItem('pez10Count')) : this.pez10Count;
    this.pez11Count = localStorage.getItem('pez11Count') != null ? Number(localStorage.getItem('pez11Count')) : this.pez11Count;
    this.pez12Count = localStorage.getItem('pez12Count') != null ? Number(localStorage.getItem('pez12Count')) : this.pez12Count;
    this.pez13Count = localStorage.getItem('pez13Count') != null ? Number(localStorage.getItem('pez13Count')) : this.pez13Count;
    this.pez14Count = localStorage.getItem('pez14Count') != null ? Number(localStorage.getItem('pez14Count')) : this.pez14Count;
    this.pez0Level = localStorage.getItem('pez0Level') != null ? Number(localStorage.getItem('pez0Level')) : this.pez0Level;
    this.pez1Level = localStorage.getItem('pez1Level') != null ? Number(localStorage.getItem('pez1Level')) : this.pez1Level;
    this.pez2Level = localStorage.getItem('pez2Level') != null ? Number(localStorage.getItem('pez2Level')) : this.pez2Level;
    this.pez3Level = localStorage.getItem('pez3Level') != null ? Number(localStorage.getItem('pez3Level')) : this.pez3Level;
    this.pez4Level = localStorage.getItem('pez4Level') != null ? Number(localStorage.getItem('pez4Level')) : this.pez4Level;
    this.pez5Level = localStorage.getItem('pez5Level') != null ? Number(localStorage.getItem('pez5Level')) : this.pez5Level;
    this.pez6Level = localStorage.getItem('pez6Level') != null ? Number(localStorage.getItem('pez6Level')) : this.pez6Level;
    this.pez7Level = localStorage.getItem('pez7Level') != null ? Number(localStorage.getItem('pez7Level')) : this.pez7Level;
    this.pez8Level = localStorage.getItem('pez8Level') != null ? Number(localStorage.getItem('pez8Level')) : this.pez8Level;
    this.pez9Level = localStorage.getItem('pez9Level') != null ? Number(localStorage.getItem('pez9Level')) : this.pez9Level;
    this.pez10Level = localStorage.getItem('pez10Level') != null ? Number(localStorage.getItem('pez10Level')) : this.pez10Level;
    this.pez11Level = localStorage.getItem('pez11Level') != null ? Number(localStorage.getItem('pez11Level')) : this.pez11Level;
    this.pez12Level = localStorage.getItem('pez12Level') != null ? Number(localStorage.getItem('pez12Level')) : this.pez12Level;
    this.pez13Level = localStorage.getItem('pez13Level') != null ? Number(localStorage.getItem('pez13Level')) : this.pez13Level;
    this.pez14Level = localStorage.getItem('pez14Level') != null ? Number(localStorage.getItem('pez14Level')) : this.pez14Level;

    this.auth.user$.subscribe((data) => {
      this.user = data
      console.log(`Este es el user ${this.user}`);
      this.usuario = {
        email: this.user.email,
        name: this.user.given_name,
        picture: this.user.picture
      }
      this.state = {
        prestigioAuto: this.prestigioAuto,
        prestigioClicks: this.prestigioClicks,
        prestigioFishPrice: this.prestigioFishPrice,
        prestigioLevel: this.prestigioLevel,
        prestigioCoins: this.prestigioCoins,
        canaEffect: this.canaEffect,
        carreteEffect: this.carreteEffect,
        pesca: this.pesca,
        coins: this.coins,
        pez0Count: this.pez0Count,
        pez1Count: this.pez1Count,
        pez2count: this.pez2Count,
        pez3Count: this.pez3Count,
        pez4Count: this.pez4Count,
        pez5Count: this.pez5Count,
        pez6Count: this.pez6Count,
        pez7Count: this.pez7Count,
        pez8Count: this.pez8Count,
        pez9Count: this.pez9Count,
        pez10Count: this.pez10Count,
        pez11Count: this.pez11Count,
        pez12Count: this.pez12Count,
        pez13Count: this.pez13Count,
        pez14Count: this.pez14Count,
        pez0Level: this.pez0Level,
        pez1Level: this.pez1Level,
        pez2Level: this.pez2Level,
        pez3Level: this.pez3Level,
        pez4Level: this.pez4Level,
        pez5Level: this.pez5Level,
        pez6Level: this.pez6Level,
        pez7Level: this.pez7Level,
        pez8Level: this.pez8Level,
        pez9Level: this.pez9Level,
        pez10Level: this.pez10Level,
        pez11Level: this.pez11Level,
        pez12Level: this.pez12Level,
        pez13Level: this.pez13Level,
        pez14Level: this.pez14Level,
        canaParts: this.canaParts,
        carreteParts: this.carreteParts,
        salabreParts: this.salabreParts,
        canaLevel: this.canaLevel,
        carreteLevel: this.carreteLevel,
        salabreLevel: this.salabreLevel,
        multLevel: this.multLevel,
        multClicks: this.multClicks,
        multPrice: this.multPrice,
        pescaLevel: this.pescaLevel,
        pescaPrice: this.pescaPrice,
        coinsAdd: this.coinsAdd,
        coinsPrice: this.coinsPrice,
        coinsLevel: this.coinsLevel,
        fishPriceMult: this.fishPriceMult,
        fishPriceMultLevel: this.fishPriceMultLevel,
        fishAuto: this.fishAuto,
        autoLevel: this.autoLevel,
      }
      localStorage.setItem(this.usuario.email, JSON.stringify(this.usuario))
    })

  }

  login() {
    this.auth.loginWithRedirect({
      appState: {
        target: 'home'
      }
    });
  }

  logout() {
    this.auth.logout({
      logoutParams: {
        returnTo: this.document.location.origin
      }
    });
  }

}
