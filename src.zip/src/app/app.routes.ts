import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'home',
    loadComponent: () => import('./home/home.page').then( m => m.HomePage)
  },
  {
    path: 'artilugios-de-pesca',
    loadComponent: () => import('./artilugios-de-pesca/artilugios-de-pesca.page').then( m => m.ArtilugiosDePescaPage)
  },
  {
    path: 'logros',
    loadComponent: () => import('./logros/logros.page').then( m => m.LogrosPage)
  },
  {
    path: 'login',
    loadComponent: () => import('./login/login.page').then( m => m.LoginPage)
  },
];
