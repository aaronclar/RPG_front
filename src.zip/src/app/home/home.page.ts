import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonContent, IonButton, IonCol, IonGrid, IonRow, IonImg } from '@ionic/angular/standalone';
import {FormsModule} from '@angular/forms'
import { AuthService } from '@auth0/auth0-angular';


@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, IonContent,IonButton, IonCol, IonGrid, IonRow, IonImg ]
})
export class HomePage implements OnInit {
  public clicks: number = 0
  public pesca: number = 100
  public pez0: number = 5
  public pez1: number = 10
  public pez2: number = 25
  public pez3: number = 50
  public pez4: number = 75
  public pez5: number = 100
  public pez6: number = 125
  public pez7: number = 150
  public pez8: number = 200
  public pez9: number = 225
  public pez10: number = 250
  public pez11: number = 275
  public pez12: number = 300
  public pez13: number = 325
  public pez14: number = 500
  public pez0Count: number = 0
  public pez1Count: number = 0
  public pez2Count: number = 0
  public pez3Count: number = 0
  public pez4Count: number = 0
  public pez5Count: number = 0
  public pez6Count: number = 0
  public pez7Count: number = 0
  public pez8Count: number = 0
  public pez9Count: number = 0
  public pez10Count: number = 0
  public pez11Count: number = 0
  public pez12Count: number = 0
  public pez13Count: number = 0
  public pez14Count: number = 0
  public coins: number = 0
  public multClicks: number = 1
  public multLevel: number = 1
  public multPrice: number = 2
  public pescaLevel: number = 1
  public autoLevel: number = 1
  public fishAuto: number = 0
  public autoPrice: number = 5
  public pescaPrice: number = 2
  public coinsAdd: number = 0
  public coinsPrice: number = 3
  public coinsLevel: number = 1
  public fishPriceMult: number = 1
  public fishPriceMultLevel: number = 1
  public desactivadoMultClicks: boolean = true
  public desactivadoPesca: boolean = true
  public desactivadoAutoFish: boolean = true
  public desactivadoCoinsAdded: boolean = true
  public desactivadoMultFishPrice: boolean = true
  public salabreParts: number = 0
  public salabreLevel: number = 1
  public canaParts: number = 0
  public canaLevel: number = 1
  public carreteLevel: number = 1
  public carreteParts: number = 0
  public canaEffect: number = 0
  public carreteEffect: number = 0
  public prestigioLevel: number = 0
  public prestigioClicks: number = 0
  public prestigioFishPrice: number = 1
  public prestigioAuto: number = 0
  public prestigioCoins: number = 0
  public desactivadoPrestigio: boolean = true
  public user: any
  public usuario: any
  constructor(private auth: AuthService) { }

  ngOnInit() {
    this.coins = localStorage.getItem('coins') != null ? Number(localStorage.getItem('coins')) : this.coins;
    this.clicks = localStorage.getItem('clicks') != null ? Number(localStorage.getItem('clicks')) : this.clicks;
    this.pesca = localStorage.getItem('pesca') != null ? Number(localStorage.getItem('pesca')) : this.pesca;
    this.multLevel = localStorage.getItem('multLevel') != null ? Number(localStorage.getItem('multLevel')) : this.multLevel;
    this.multClicks = localStorage.getItem('multClicks') != null ? Number(localStorage.getItem('multClicks')) : this.multClicks;
    this.pescaLevel = localStorage.getItem('pescaLevel') != null ? Number(localStorage.getItem('pescaLevel')) : this.pescaLevel;
    this.autoLevel = localStorage.getItem('autoLevel') != null ? Number(localStorage.getItem('autoLevel')) : this.autoLevel;
    this.fishAuto = localStorage.getItem('fishAuto') != null ? Number(localStorage.getItem('fishAuto')) : this.fishAuto;
    this.autoPrice = localStorage.getItem('autoPrice') != null ? Number(localStorage.getItem('autoPrice')) : this.autoPrice;
    this.multPrice = localStorage.getItem('multPrice') != null ? Number(localStorage.getItem('multPrice')) : this.multPrice;
    this.pescaPrice = localStorage.getItem('pescaPrice') != null ? Number(localStorage.getItem('pescaPrice')) : this.pescaPrice;
    this.coinsAdd = localStorage.getItem('coinsAdd') != null ? Number(localStorage.getItem('coinsAdd')) : this.coinsAdd;
    this.coinsPrice = localStorage.getItem('coinsPrice') != null ? Number(localStorage.getItem('coinsPrice')) : this.coinsPrice;
    this.coinsLevel = localStorage.getItem('coinsLevel') != null ? Number(localStorage.getItem('coinsLevel')) : this.coinsLevel;
    this.fishPriceMult = localStorage.getItem('fishPriceMult') != null ? Number(localStorage.getItem('fishPriceMult')) : this.fishPriceMult;
    this.fishPriceMultLevel = localStorage.getItem('fishPriceMultLevel') != null ? Number(localStorage.getItem('fishPriceMultLevel')) : this.fishPriceMultLevel;
    this.canaParts = localStorage.getItem('canaParts') != null ? Number(localStorage.getItem('canaParts')) : this.canaParts;
    this.canaLevel = localStorage.getItem('canaLevel') != null ? Number(localStorage.getItem('canaLevel')) : this.canaLevel;
    this.carreteParts = localStorage.getItem('carreteParts') != null ? Number(localStorage.getItem('carreteParts')) : this.carreteParts;
    this.carreteLevel = localStorage.getItem('carreteLevel') != null ? Number(localStorage.getItem('carreteLevel')) : this.carreteLevel;
    this.salabreParts = localStorage.getItem('salabreParts') != null ? Number(localStorage.getItem('salabreParts')) : this.salabreParts;
    this.salabreLevel = localStorage.getItem('salabreLevel') != null ? Number(localStorage.getItem('salabreLevel')) : this.salabreLevel;
    this.canaEffect = localStorage.getItem('canaEffect') != null ? Number(localStorage.getItem('canaEffect')) : this.canaEffect;
    this.carreteEffect = localStorage.getItem('carreteEffect') != null ? Number(localStorage.getItem('carreteEffect')) : this.carreteEffect;
    this.pez0Count = localStorage.getItem('pez0Count') != null ? Number(localStorage.getItem('pez0Count')) : this.pez0Count;
    this.pez1Count = localStorage.getItem('pez1Count') != null ? Number(localStorage.getItem('pez1Count')) : this.pez1Count;
    this.pez2Count = localStorage.getItem('pez2Count') != null ? Number(localStorage.getItem('pez2Count')) : this.pez2Count;
    this.pez3Count = localStorage.getItem('pez3Count') != null ? Number(localStorage.getItem('pez3Count')) : this.pez3Count;
    this.pez4Count = localStorage.getItem('pez4Count') != null ? Number(localStorage.getItem('pez4Count')) : this.pez4Count;
    this.pez5Count = localStorage.getItem('pez5Count') != null ? Number(localStorage.getItem('pez5Count')) : this.pez5Count;
    this.pez6Count = localStorage.getItem('pez6Count') != null ? Number(localStorage.getItem('pez6Count')) : this.pez6Count;
    this.pez7Count = localStorage.getItem('pez7Count') != null ? Number(localStorage.getItem('pez7Count')) : this.pez7Count;
    this.pez8Count = localStorage.getItem('pez8Count') != null ? Number(localStorage.getItem('pez8Count')) : this.pez8Count;
    this.pez9Count = localStorage.getItem('pez9Count') != null ? Number(localStorage.getItem('pez9Count')) : this.pez9Count;
    this.pez10Count = localStorage.getItem('pez10Count') != null ? Number(localStorage.getItem('pez10Count')) : this.pez10Count;
    this.pez11Count = localStorage.getItem('pez11Count') != null ? Number(localStorage.getItem('pez11Count')) : this.pez11Count;
    this.pez12Count = localStorage.getItem('pez12Count') != null ? Number(localStorage.getItem('pez12Count')) : this.pez12Count;
    this.pez13Count = localStorage.getItem('pez13Count') != null ? Number(localStorage.getItem('pez13Count')) : this.pez13Count;
    this.pez14Count = localStorage.getItem('pez14Count') != null ? Number(localStorage.getItem('pez14Count')) : this.pez14Count;
    this.prestigioLevel = localStorage.getItem('prestigioLevel') != null ? Number(localStorage.getItem('prestigioLevel')) : this.prestigioLevel;
    this.prestigioClicks = localStorage.getItem('prestigioClicks') != null ? Number(localStorage.getItem('prestigioClicks')) : this.prestigioClicks;
    this.prestigioFishPrice = localStorage.getItem('prestigioFishPrice') != null ? Number(localStorage.getItem('prestigioFishPrice')) : this.prestigioFishPrice;
    this.prestigioAuto = localStorage.getItem('prestigioAuto') != null ? Number(localStorage.getItem('prestigioAuto')) : this.prestigioAuto;
    this.prestigioCoins = localStorage.getItem('prestigioCoins') != null ? Number(localStorage.getItem('prestigioCoins')) : this.prestigioCoins;
    setInterval(() => {
      this.fishAutoAction();
      this.checkdisable();
  }, 1000);
  this.auth.user$.subscribe((data) =>{
    this.user =data
    console.log(this.user);
    this.usuario = {
      email: this.user.email,
      name: this.user.name,
      picture: this.user.picture
    }
    localStorage.setItem(this.usuario.email, JSON.stringify(this.usuario))
  })

  }
  clickPlus(){
    this.clicks = Number((this.clicks + (1 * this.multClicks) + this.canaEffect + this.prestigioClicks).toFixed(2));
    this.coins = Number((this.coins + this.coinsAdd + this.prestigioCoins).toFixed(2));
    console.log(this.clicks)
    localStorage.setItem('clicks', String(this.clicks))
    localStorage.setItem('coins', String(this.coins))
    localStorage.setItem('multClicks', String(this.multClicks))
    localStorage.setItem('multLevel', String(this.multLevel))
    localStorage.setItem('pescaLevel', String(this.pescaLevel))
    localStorage.setItem('pesca', String(this.pesca))
    if(this.clicks >= this.pesca){
      this.clicks = 0
      let random = Math.floor(Math.random() * this.pesca)
      if(random == 1 || random==101 || random == 151 || random == 201){
        this.canaParts += 1
        alert('Has encontrado una parte de caña')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('canaParts', String(this.canaParts))
      } else if (random == 2 || random == 102 || random == 152 || random == 202){
        this.salabreParts += 1
        alert('Has encontrado una parte de salabre')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('salabreParts', String(this.salabreParts))
      } else if (random == 3 || random == 103 || random == 153 || random == 203){
        this.carreteParts += 1
        alert('Has encontrado una parte de carrete')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('carreteParts', String(this.carreteParts))
      } else if(random < 30){
        this.coins = Number((this.coins + ((this.pez0 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez0Count += 1
        alert('Has pescado un Serrano')
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('pez0Count', String(this.pez0Count))
      } else if(random < 70){
        this.coins = Number((this.coins + ((this.pez1 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez1Count += 1
        alert('Has pescado un Salmonete')
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('pez1Count', String(this.pez1Count))
      } else if(random < 80){
        this.coins = Number((this.coins + ((this.pez2 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez2Count += 1
        alert('Has pescado un Lenguado')
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('pez2Count', String(this.pez2Count))
      } else if (random < 90){
        this.coins = Number((this.coins + ((this.pez3 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez3Count += 1
        alert('Has pescado un Cabracho')
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('pez3Count', String(this.pez3Count))
      } else if (random < 100){
        this.coins = Number((this.coins + ((this.pez4 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez4Count += 1
        alert('Has pescado un Bonito')
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('pez4Count', String(this.pez4Count))
      } else if (random < 110){
        this.coins = Number((this.coins + ((this.pez5 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez5Count += 1
        alert('Has pescado una Corvina')
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('pez5Count', String(this.pez5Count))
      } else if (random < 120){
        this.coins = Number((this.coins + ((this.pez6 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez6Count += 1
        alert('Has pescado un Calamar')
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('pez6Count', String(this.pez6Count))
      } else if (random < 130){
        this.coins = Number((this.coins + ((this.pez7 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez7Count += 1
        alert('Has pescado un Dentón')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez7Count', String(this.pez7Count))
      }else if (random < 140){
        this.coins = Number((this.coins + ((this.pez8 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez8Count += 1
        alert('Has pescado una Morena')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez8Count', String(this.pez8Count))
      }else if (random < 150){
        this.coins = Number((this.coins + ((this.pez9 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez9Count += 1
        alert('Has pescado una Barracuda')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez9Count', String(this.pez9Count))
      }else if (random < 160){
        this.coins = Number((this.coins + ((this.pez10 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez10Count += 1
        alert('Has pescado un Rape')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez10Count', String(this.pez10Count))
      } else if (random < 170){
        this.coins = Number((this.coins + ((this.pez12 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez11Count += 1
        alert('Has pescado un Mero')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez11Count', String(this.pez11Count))
      } else if (random < 180){
        this.coins = Number((this.coins + ((this.pez12 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez12Count += 1
        alert('Has pescado un Pejerrey')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez12Count', String(this.pez12Count))
      }  else if (random < 200){
        this.coins = Number((this.coins + ((this.pez13 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez13Count += 1
        alert('Has pescado un Atún')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez13Count', String(this.pez13Count))
      } else {
        this.coins = Number((this.coins + ((this.pez14 * this.fishPriceMult) * this.prestigioFishPrice)).toFixed(2))
        this.pez14Count += 1
        alert('Has pescado un Pez Vela')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez14Count', String(this.pez14Count))
      }
    }
    
  }
  multCLicks(){
    if(this.coins >= this.multPrice){
      this.coins = Number((this.coins - this.multPrice).toFixed(2))
      this.multClicks = Number((this.multClicks + 0.1).toFixed(2));
      this.multLevel += 1
      this.multPrice += 2
      localStorage.setItem('multClicks', String(this.multClicks))
      localStorage.setItem('multLevel', String(this.multLevel))
      localStorage.setItem('multPrice', String(this.multPrice))
      localStorage.setItem('coins', String(this.coins))
    } else {
      
    }
  }
  multPesca(){
    if(this.coins >= this.pescaPrice){
      this.coins = Number((this.coins - this.pescaPrice).toFixed(2))
      this.pescaLevel += 1
      this.pesca += 1
      this.pescaPrice += 2
      localStorage.setItem('pescaLevel', String(this.pescaLevel))
      localStorage.setItem('pesca', String(this.pesca))
      localStorage.setItem('pescaPrice', String(this.pescaPrice))
      localStorage.setItem('coins', String(this.coins))
    } else {
      
    }
  }
  autoFish(){
    if(this.coins >= this.autoPrice){
      this.coins = Number((this.coins - this.autoPrice).toFixed(2))
      this.autoPrice += 5
      this.autoLevel += 1
      this.fishAuto = Number((this.fishAuto + 0.05).toFixed(2));
      localStorage.setItem('coins', String(this.coins));
      localStorage.setItem('autoLevel' , String(this.autoLevel));
      localStorage.setItem('fishAuto', String(this.fishAuto));
      localStorage.setItem('autoPrice', String(this.autoPrice));
    } else {
      
    }
  }
  coinsAdded(){
    if(this.coins >= this.coinsPrice){
      this.coins = Number((this.coins - this.coinsPrice).toFixed(2))
      this.coinsPrice += 3
      this.coinsLevel += 1
      this.coinsAdd = Number((this.coinsAdd + 0.025).toFixed(3));
      localStorage.setItem('coins', String(this.coins));
      localStorage.setItem('coinsAdd', String(this.coinsAdd));
      localStorage.setItem('coinsPrice', String(this.coinsPrice));
      localStorage.setItem('coinsLevel', String(this.coinsLevel));
    } else {
      
    }
  }
  multFishPrice(){
    if(this.coins >= this.fishPriceMultLevel){
      this.coins = Number((this.coins - this.fishPriceMultLevel).toFixed(2))
      this.fishPriceMultLevel += 1
      this.fishPriceMult = Number((this.fishPriceMult + 0.01).toFixed(2))
      localStorage.setItem('coins', String(this.coins));
      localStorage.setItem('fishPriceMult', String(this.fishPriceMult));
      localStorage.setItem('fishPriceMultLevel', String(this.fishPriceMultLevel));
    } else {
      
    }
  }

  // ngOnIt Auto Functions 

  fishAutoAction(){
    this.clicks = Number((this.clicks + this.fishAuto + this.carreteEffect + this.prestigioAuto).toFixed(2));
    localStorage.setItem('clicks', String(this.clicks));
    if(this.clicks >= this.pesca){
      this.clicks = 0
      let random = Math.floor(Math.random() * this.pesca)
      if(random == 1 || random==101 || random == 151 || random == 201){
        this.canaParts += 1
        alert('Has encontrado una parte de caña')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('canaParts', String(this.canaParts))
      } else if (random == 2 || random == 102 || random == 152 || random == 202){
        this.salabreParts += 1
        alert('Has encontrado una parte de salabre')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('salabreParts', String(this.salabreParts))
      } else if (random == 3 || random == 103 || random == 153 || random == 203){
        this.carreteParts += 1
        alert('Has encontrado una parte de carrete')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('carreteParts', String(this.carreteParts))
      } else if(random < 30){
        this.coins = Number((this.coins + (this.pez0 * this.fishPriceMult)).toFixed(2))
        this.pez0Count += 1
        alert('Has pescado un Serrano')
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('pez0Count', String(this.pez0Count))
      } else if(random < 70){
        this.coins = Number((this.coins + (this.pez1 * this.fishPriceMult)).toFixed(2))
        this.pez1Count += 1
        alert('Has pescado un Salmonete')
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('pez1Count', String(this.pez1Count))
      } else if(random < 80){
        this.coins = Number((this.coins + (this.pez2 * this.fishPriceMult)).toFixed(2))
        this.pez2Count += 1
        alert('Has pescado un Lenguado')
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('pez2Count', String(this.pez2Count))
      } else if (random < 90){
        this.coins = Number((this.coins + (this.pez3 * this.fishPriceMult)).toFixed(2))
        this.pez3Count += 1
        alert('Has pescado un Cabracho')
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('pez3Count', String(this.pez3Count))
      } else if (random < 100){
        this.coins = Number((this.coins + (this.pez4 * this.fishPriceMult)).toFixed(2))
        this.pez4Count += 1
        alert('Has pescado un Bonito')
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('pez4Count', String(this.pez4Count))
      } else if (random < 110){
        this.coins = Number((this.coins + (this.pez5 * this.fishPriceMult)).toFixed(2))
        this.pez5Count += 1
        alert('Has pescado una Corvina')
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('pez5Count', String(this.pez5Count))
      } else if (random < 120){
        this.coins = Number((this.coins + (this.pez6 * this.fishPriceMult)).toFixed(2))
        this.pez6Count += 1
        alert('Has pescado un Calamar')
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('pez6Count', String(this.pez6Count))
      } else if (random < 130){
        this.coins = Number((this.coins + (this.pez7 * this.fishPriceMult)).toFixed(2))
        this.pez7Count += 1
        alert('Has pescado un Dentón')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez7Count', String(this.pez7Count))
      }else if (random < 140){
        this.coins = Number((this.coins + (this.pez8 * this.fishPriceMult)).toFixed(2))
        this.pez8Count += 1
        alert('Has pescado una Morena')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez8Count', String(this.pez8Count))
      }else if (random < 150){
        this.coins = Number((this.coins + (this.pez9 * this.fishPriceMult)).toFixed(2))
        this.pez9Count += 1
        alert('Has pescado una Barracuda')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez9Count', String(this.pez9Count))
      }else if (random < 160){
        this.coins = Number((this.coins + (this.pez10 * this.fishPriceMult)).toFixed(2))
        this.pez10Count += 1
        alert('Has pescado un Rape')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez10Count', String(this.pez10Count))
      } else if (random < 170){
        this.coins = Number((this.coins + (this.pez11 * this.fishPriceMult)).toFixed(2))
        this.pez11Count += 1
        alert('Has pescado un Mero')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez11Count', String(this.pez11Count))
      } else if (random < 180){
        this.coins = Number((this.coins + (this.pez12 * this.fishPriceMult)).toFixed(2))
        this.pez12Count += 1
        alert('Has pescado un Pejerrey')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez12Count', String(this.pez12Count))
      }  else if (random < 200){
        this.coins = Number((this.coins + (this.pez13 * this.fishPriceMult)).toFixed(2))
        this.pez13Count += 1
        alert('Has pescado un Atún')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez13Count', String(this.pez13Count))
      } else {
        this.coins = Number((this.coins + (this.pez14 * this.fishPriceMult)).toFixed(2))
        this.pez14Count += 1
        alert('Has pescado un Pez Vela')
        localStorage.setItem('clicks', String(this.clicks))
        localStorage.setItem('coins', String(this.coins))
        localStorage.setItem('pez14Count', String(this.pez14Count))
      }
    }
  }

  checkdisable(){
    if(this.coins >= this.multPrice){
      this.desactivadoMultClicks = false
    } else{
      this.desactivadoMultClicks = true
    }
    if(this.coins >= this.pescaPrice){
      this.desactivadoPesca = false
    } else{
      this.desactivadoPesca = true
    }
    if(this.coins >= this.autoPrice){
      this.desactivadoAutoFish = false
    } else{
      this.desactivadoAutoFish = true
    }
    if(this.coins >= this.coinsPrice){
      this.desactivadoCoinsAdded = false
    } else{
      this.desactivadoCoinsAdded = true
    }
    if(this.coins >= this.fishPriceMultLevel){
      this.desactivadoMultFishPrice = false
    } else{
      this.desactivadoMultFishPrice = true
    }
    if(this.pesca >= 210 && this.multLevel >= 100 && this.autoLevel >= 50 && this.fishPriceMultLevel >=100 && this.coinsLevel >= 75){
      this.desactivadoPrestigio = false
    } else {
      this.desactivadoPrestigio = true
    }
  }

  //Prestigio
 clearCache(){
  this.prestigioLevel += 1
  this.prestigioClicks += 1
  this.prestigioCoins = Number((this.prestigioCoins + 0.25).toFixed(2))
  this.prestigioAuto = Number((this.prestigioAuto + 0.5).toFixed(2))
  this.prestigioFishPrice = Number((this.prestigioFishPrice + 0.5).toFixed(2))
  localStorage.setItem('prestigioLevel', String(this.prestigioLevel))
  localStorage.setItem('prestigioClicks', String(this.prestigioClicks))
  localStorage.setItem('prestigioCoins', String(this.prestigioCoins))
  localStorage.setItem('prestigioAuto', String(this.prestigioAuto))
  localStorage.setItem('prestigioFishPrice', String(this.prestigioFishPrice))
  localStorage.setItem('coins', String(0));
  localStorage.setItem('clicks', String(0));
  localStorage.setItem('multClicks', String(1));
  localStorage.setItem('multLevel', String(1));
  localStorage.setItem('multPrice', String(2));
  localStorage.setItem('pescaLevel', String(1));
  localStorage.setItem('pesca', String(100));
  localStorage.setItem('pescaPrice', String(2));
  localStorage.setItem('autoLevel', String(1));
  localStorage.setItem('fishAuto', String(0));
  localStorage.setItem('autoPrice', String(5));
  localStorage.setItem('coinsAdd', String(0));
  localStorage.setItem('coinsPrice', String(3));
  localStorage.setItem('coinsLevel', String(1));
  localStorage.setItem('fishPriceMult', String(1));
  localStorage.setItem('fishPriceMultLevel', String(1));
  location.reload()
 }
}
