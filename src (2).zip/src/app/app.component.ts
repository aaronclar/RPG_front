
import { Component, OnInit } from '@angular/core';
import { RouterLink, RouterLinkActive } from '@angular/router';
import { IonMenu, IonHeader, IonToolbar, IonContent, IonTitle, IonButtons, IonMenuButton, IonList, IonListHeader, IonMenuToggle, IonItem, IonIcon, IonLabel, IonRouterOutlet, IonRouterLink } from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { mailOutline, skullOutline, mailSharp, paperPlaneOutline, paperPlaneSharp,buildOutline, buildSharp,earthOutline, earthSharp, heartOutline, heartSharp, archiveOutline, archiveSharp, trashOutline, trashSharp, warningOutline, warningSharp, bookmarkOutline, bookmarkSharp, skullSharp, receiptSharp, logOutSharp } from 'ionicons/icons';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  imports: [RouterLink, RouterLinkActive, IonHeader, IonToolbar, IonTitle, IonButtons, IonMenuButton, IonMenu, IonContent, IonList, IonListHeader, IonMenuToggle, IonItem, IonIcon, IonLabel, IonRouterLink, IonRouterOutlet],
})
export class AppComponent implements OnInit {
  public appPages = [
    { title: 'Home', url: 'home', icon: 'earth' },
    { title: 'Deudas', url: 'deudas', icon: 'skull'},
    { title: 'Pagados', url: 'pagados', icon: 'receipt'},
    { title: 'Login', url: 'login', icon: 'log-out'},


  ];
  public labels = [];
  constructor() {
    addIcons({ mailOutline, receiptSharp, skullOutline, logOutSharp, skullSharp, buildOutline, buildSharp,earthOutline, earthSharp, mailSharp, paperPlaneOutline, paperPlaneSharp, heartOutline, heartSharp, archiveOutline, archiveSharp, trashOutline, trashSharp, warningOutline, warningSharp, bookmarkOutline, bookmarkSharp });
  }
  ngOnInit(){

  }
}
