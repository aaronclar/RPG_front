import { Component, OnInit, Inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonHeader, IonTitle, IonToolbar, IonButton } from '@ionic/angular/standalone';
import { AuthService } from '@auth0/auth0-angular';
import { DOCUMENT } from '@angular/common';



@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: true,
  imports: [IonContent, IonHeader, IonTitle, IonToolbar, CommonModule, FormsModule, IonButton]
})
export class LoginPage implements OnInit {
 
  public user: any;
  public usuario: any
  public state: any = {};
  constructor(private auth: AuthService, @Inject(DOCUMENT) public document: Document) { }

  ngOnInit() {
    
    this.auth.user$.subscribe((data) => {
      this.user = data
      console.log(`Este es el user ${this.user}`);
      this.usuario = {
        email: this.user.email,
        name: this.user.given_name,
        picture: this.user.picture,
        estado: this.state
      }
      
    })

  }

  login() {
    this.auth.loginWithRedirect({
      appState: {
        target: 'home'
      }
    });
  }

  logout() {
    this.auth.logout({
      logoutParams: {
        returnTo: this.document.location.origin
      }
    });
  }

}
