import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonContent, IonList, IonLabel, IonItem, IonButton, IonCol, IonGrid, IonRow, IonImg, IonTitle, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, } from '@ionic/angular/standalone';
import { AuthService } from '@auth0/auth0-angular';

@Component({
  selector: 'app-pagados',
  templateUrl: './pagados.page.html',
  styleUrls: ['./pagados.page.scss'],
  standalone: true,
  imports: [CommonModule, FormsModule, IonContent, IonButton, IonCol, IonGrid, IonRow, IonImg, IonTitle, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonList, IonLabel, IonItem]
})
export class PagadosPage implements OnInit {
  public date: Date = new Date();
  public total: number = 0
  public user: any
  public usuario: any
  public state : any = {
    itemsd : [],
    itemsp : []
  }


  constructor(private auth: AuthService) { }

  ngOnInit() {
    this.state.itemsd = JSON.parse(localStorage.getItem("itemsd") || "[]");
    this.state.itemsp = JSON.parse(localStorage.getItem("itemsp") || "[]");
    console.log(this.state.itemsd)
    this.auth.user$.subscribe((data: any) => {
      this.user = data;
      console.log(this.user)
      this.usuario = {
        email: data.email,
        name: data.given_name,
        picture: data.picture
      }
      this.loadstate();
    });
    console.log(JSON.stringify(this.state.itemsp))
  }

  totalf() {
    for (let i = 0; i < this.state.itemsp.length; i++) {
      this.total += this.state.itemsp[i].price
    }
  }

  loadstate(){
    let cache_state = localStorage.getItem(this.usuario.email)
    if(cache_state != null){
      this.state = JSON.parse(cache_state);
      this.totalf()
    }
  }

  saveState(){
    localStorage.setItem(this.usuario.email, JSON.stringify(this.state))
  }

}
