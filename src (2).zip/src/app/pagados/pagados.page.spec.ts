import { ComponentFixture, TestBed } from '@angular/core/testing';
import { PagadosPage } from './pagados.page';

describe('PagadosPage', () => {
  let component: PagadosPage;
  let fixture: ComponentFixture<PagadosPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(PagadosPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
