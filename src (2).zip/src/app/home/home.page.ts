import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonContent, IonButton, IonCol, IonHeader, IonGrid, IonRow, IonImg, IonTitle, IonCard, IonCardHeader,IonCardTitle, IonCardSubtitle, IonCardContent, } from '@ionic/angular/standalone';
import {FormsModule} from '@angular/forms'
import { AuthService } from '@auth0/auth0-angular';
import { DatePipe } from '@angular/common';


@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: true,
  imports: [CommonModule, DatePipe, FormsModule, IonHeader, IonContent,IonButton, IonCol, IonGrid, IonRow, IonImg, IonTitle, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, ]
})
export class HomePage implements OnInit {
  public datepipe: DatePipe = new DatePipe('en-US')
  public date: Date = new Date()
  public user: any
  public usuario: any
  public total : number = 0
  
  public state : any = {
    itemsd : [],
    itemsp : []
  }
  public items : {name : string; price : number}[] = [
    {
      name: "Napolitana",
      price : 2
    },
    {
      name: "Café",
      price : 1
    },
    {
      name: "Bocata jamón serrano",
      price : 3
    },
    {
      name: "Bocata bacon",
      price : 3.5
    },
    {
      name: "Agua",
      price : 1
    },
    {
      name: "Cocacola",
      price : 2
    }
  ]

  constructor(private auth: AuthService) { }

  ngOnInit() {
    this.state.itemsd = JSON.parse(localStorage.getItem("itemsd") || "[]")
    this.state.itemsp = JSON.parse(localStorage.getItem("itemsp") || "[]")
    this.auth.user$.subscribe((data: any) => {
      this.user = data;
      console.log(this.user)
      this.usuario = {
        email: data.email,
        name: data.given_name,
        picture: data.picture
      }
      this.loadstate();
    })
  }

  loadstate(){
    let cache_state = localStorage.getItem(this.usuario.email)
    if(cache_state != null){
      this.state = JSON.parse(cache_state);
      this.totalf();
    }  
  }

  saveState(){
    localStorage.setItem(this.usuario.email, JSON.stringify(this.state))
  }

  anadirdeuda(name : string){
    for(let i = 0; i < this.items.length; i++){
      if(this.items[i].name === name){
        let formattedDate = this.datepipe.transform(this.date, "dd-MMM HH:mm")
        this.state.itemsd.push({name: JSON.stringify(this.items[i].name), price: Number(this.items[i].price), fecha_compra: String(formattedDate) }) 
        localStorage.setItem('itemsd', JSON.stringify(this.state.itemsd))
    }
  }
  this.totalf();
  console.log(this.state.itemsd)
  this.saveState();
  }

  totalf(){
    this.total = 0;
    for(let i = 0; i < this.state.itemsd.length; i++){
      this.total += this.state.itemsd[i].price
  }
}
}
