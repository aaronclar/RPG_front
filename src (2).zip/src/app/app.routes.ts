import { Routes } from '@angular/router';
import { AuthGuard } from '@auth0/auth0-angular';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'login',
    pathMatch: 'full'
  },
  {
    path: 'home',
    loadComponent: () => import('./home/home.page').then( m => m.HomePage),
    canActivate : [AuthGuard]
  },
  {
    path: 'login',
    loadComponent: () => import('./login/login.page').then( m => m.LoginPage)
    
  },
  {
    path: 'deudas',
    loadComponent: () => import('./deudas/deudas.page').then( m => m.DeudasPage),
    canActivate : [AuthGuard]
  },
  {
    path: 'pagados',
    loadComponent: () => import('./pagados/pagados.page').then( m => m.PagadosPage),
    canActivate : [AuthGuard]
  },
];
