import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonContent, IonList, IonLabel, IonItem , IonButton, IonCol, IonGrid, IonRow, IonImg, IonTitle, IonCard, IonCardHeader,IonCardTitle, IonCardSubtitle, IonCardContent, } from '@ionic/angular/standalone';
import {FormsModule} from '@angular/forms'
import { AuthService } from '@auth0/auth0-angular';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-deudas',
  templateUrl: './deudas.page.html',
  styleUrls: ['./deudas.page.scss'],
  standalone: true,
  imports: [CommonModule, DatePipe, FormsModule, IonContent,IonButton, IonCol, IonGrid, IonRow, IonImg, IonTitle, IonCard, IonCardHeader, IonCardTitle, IonCardSubtitle, IonCardContent, IonList, IonLabel, IonItem ]
})
export class DeudasPage implements OnInit {
  public datepipe: DatePipe = new DatePipe('en-US')
  public date: Date = new Date();
  public total: number = 0
  public user: any
  public usuario: any
  public state : any = {
    itemsd : [],
    itemsp : []
  }
  

  constructor(private auth: AuthService) { }

  ngOnInit() {
    this.state.itemsd = JSON.parse(localStorage.getItem("itemsd") || "[]");
    this.state.itemsp = JSON.parse(localStorage.getItem("itemsp") || "[]");
    console.log(this.state.itemsd)
    this.auth.user$.subscribe((data: any) => {
      this.user = data;
      console.log(this.user)
      this.usuario = {
        email: data.email,
        name: data.given_name,
        picture: data.picture
      }
      this.loadstate();
    });
    console.log(JSON.stringify(this.state.itemsp))
  }
  loadstate(){
    let cache_state = localStorage.getItem(this.usuario.email)
    if(cache_state != null){
      this.state = JSON.parse(cache_state);
      this.totalf()
    }
  }

  saveState(){
    localStorage.setItem(this.usuario.email, JSON.stringify(this.state))
  }

  totalf(){
    for(let i = 0; i < this.state.itemsd.length; i++){
      this.total += this.state.itemsd[i].price
  }
}

  pagar(){
    this.total = 0
    for(let i = 0; i < this.state.itemsd.length; i++){
      let formattedDate = this.datepipe.transform(this.date, "dd-MMM HH:mm")
        this.state.itemsp.push({name: String(this.state.itemsd[i].name), price: Number(this.state.itemsd[i].price), fecha_compra: String(formattedDate)}) 
        localStorage.setItem('itemsp', JSON.stringify(this.state.itemsp))
        this.state.itemsp = JSON.parse(localStorage.getItem("itemsp") || "[]");
    }
    while(this.state.itemsd.length > 0){
      this.state.itemsd.shift();
    }
    localStorage.setItem("itemsd", JSON.stringify(this.state.itemsd));
    console.log(`Items historial ${JSON.stringify(this.state.itemsp)}`)
    this.saveState();
  }
}